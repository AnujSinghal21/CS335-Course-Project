def func() -> None:
    y:int = 10
    y = x
    return

