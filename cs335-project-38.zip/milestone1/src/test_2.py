def func(x:int, y:int ) -> int:
    t:int  = x + y



def main():
    l:list[int] = [100,12,2321,2132]

    a:int = l[1]
    y:int = 100
    func(a, y)
